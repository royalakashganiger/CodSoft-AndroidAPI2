# Simple Alarm Clock
Simple Alarm Clock is a small application showing MVVM architecture and Room persistence library implementation.
This app allows user to set one-time or repeating alarms with a simple UI.

<img src="screenshots/Screenshot_20200929-194719_Simple Alarm Clock.jpg" height="400" alt="Screenshot"/> <img src="screenshots/Screenshot_20200929-194746_Simple Alarm Clock.jpg" height="400" alt="Screenshot"/> <img src="screenshots/Screenshot_20200929-195011_Simple Alarm Clock.jpg" height="400" alt="Screenshot"/>
